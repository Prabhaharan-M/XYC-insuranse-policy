﻿using Demo2.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;


namespace Demo2.Controllers
{
    
    public class HomeController : Controller
    {
        public static void LogFileEntry(string message)
        {
            FileStream fs = new FileStream("C:\\Users\\prabhaharan_m\\source\\repos\\Demo2\\Demo2\\wwwroot\\NewFolder\\LogDetails.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(message);
            sw.Close();
        }

        public static void ClaimRequestEntry(string message)
        {
            FileStream fs = new FileStream("C:\\Users\\prabhaharan_m\\source\\repos\\Demo2\\Demo2\\wwwroot\\NewFolder\\ClaimHistory.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(message);
            sw.Close();
        }


        private readonly ILogger<HomeController> _logger;
        NewInsuranceDBContext inc = new NewInsuranceDBContext();
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        //Homepage 
        public IActionResult HomePage()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        //Get user interface
        [HttpGet]
        [Authorize]
        public IActionResult userprofile()
        {
            var uid = HttpContext.Session.GetInt32("Userid");

            var user = inc.LoginDetails.Where(x => x.Userid == uid).FirstOrDefault();
            if (user != null)
            {
                return View(user);
            }
            else
            {
                ViewBag.ErrorMessage = "Try Logging in, Please!";
                return RedirectToAction("Login", "Home");
            }
        }

        //To Register New policy
        [HttpGet]
        [Authorize]
        public IActionResult RegisterNewPolicy(int id)
        {
            ViewBag.Id = id;
            return View();
        }


        [HttpPost]
        [Authorize]
        public IActionResult RegisterNewPolicy(UserDetail user, IFormCollection f)
        {
            user.Policydate = DateTime.Now;
            inc.UserDetails.Add(user);
            Console.WriteLine(DateTime.Now);
            inc.SaveChanges();
            return RedirectToAction("userprofile", new {id= HttpContext.Session.GetInt32("Userid") });
        }

        //List of Policy insured by User
        [HttpGet]
        [Authorize]
        public IActionResult ClaimPolicy(int id)
        {
            int uid = id;
            var Policylist = inc.UserDetails.Where(x => x.Userid == id).ToList();
            ViewBag.Id = uid;
            if (Policylist.Count == 0)
            {
                ViewBag.ListStatus = "There is No Policy available right now Please go and Register new policy!...";
            }
            return View(Policylist);
        }

        //To edit User detail
        [HttpGet]
        [Authorize]
        public IActionResult EditUser(int id)
        {
            var u1 = inc.LoginDetails.Where(x => x.Userid == id).FirstOrDefault();
            return View(u1);
        }


        [HttpPost]
        [Authorize]
        public IActionResult EditUser(LoginDetail user)
        {
            var u1 = inc.LoginDetails.Where(x => x.Userid == user.Userid).FirstOrDefault();
            inc.LoginDetails.Remove(u1);
            inc.LoginDetails.Add(user);
            inc.SaveChanges();
            return RedirectToAction("userprofile");
        }

        //To view full details about policy by policy No
        [HttpGet]
        [Authorize]
        public IActionResult viewpolicy(int id)
        {
            var view1 = inc.UserDetails.Where(x => x.Policyno == id).FirstOrDefault();
            return View(view1);
        }

        //To raise a claim for the policy based on policy No
        [HttpGet]
        [Authorize]
        public IActionResult Claim(int id)
        {
            var user = inc.UserDetails.Where(x => x.Policyno == id).FirstOrDefault();
            ViewBag.userid = user.Userid;
            ViewBag.policyno = user.Policyno;
            if (((DateTime.Now.Year - user.Policydate.Value.Year) * 12 + (DateTime.Now.Month - user.Policydate.Value.Month  )) < 6)
            {
                ViewBag.DateError = "Cannot claim amount before 6 months from Policy date!!!";
            }
            return View();
        }

        //Check policy detail for raise claim
        [HttpPost]
        [Authorize]
        public IActionResult Claim(ClaimDetail claim)
        {
           
            var user = inc.UserDetails.Where(x=>x.Policyno == claim.Policyno).FirstOrDefault();
            ViewBag.userid = user.Userid;
            ViewBag.policyno = user.Policyno;
            if (user.Policytype.ToLower() == "basic")
            {
                double maxclaim = (double)(0.7 * user.Policyamount);
                if((double)claim.Claimedamount > maxclaim)
                {
                    ViewBag.MaxClaim = "Enter amount below" + maxclaim;
                    return View();
                }
                else
                {
                    claim.Claimdate = DateTime.Now;
                    claim.Status = "Pending";
                    inc.ClaimDetails.Add(claim);
                    inc.SaveChanges();
                    string str ="User "+ user.Customername + " Raised a Claim on " + DateTime.Now.ToString() + " with Policy No " + user.Policyno + " and Claim No " + claim.Claimno;
                    ClaimRequestEntry(str);
                    return RedirectToAction("userprofile");
                }
            }
            else
            {
                double maxclaim = (double)(0.9 * user.Policyamount);
                if ((double)claim.Claimedamount > maxclaim)
                {
                    ViewBag.MaxClaim = "For your plan Maximum claim amount is " + maxclaim;
                    return View();
                }
                else
                {
                    claim.Claimdate = DateTime.Now;
                    claim.Status = "Pending";
                    inc.ClaimDetails.Add(claim);
                    inc.SaveChanges();
                    string str = "User " + user.Customername + " Raised a Claim on " + DateTime.Now.ToString() + " with Policy No " + user.Policyno + " and Claim No " + claim.Claimno;
                    ClaimRequestEntry(str);
                    return RedirectToAction("userprofile");
                }
            }   
        }

        //List of claim Raised by user(Total Claim History of particular user)
        [HttpGet]
        [Authorize]
        public IActionResult MyClaim(int id)
        {
            var claimlist = inc.ClaimDetails.Where(x => x.Userid == id).ToList();
            if (claimlist.Count == 0)
            {
                ViewBag.ListStatus = "There is No claim available right now Please go and raise claim!...";
            }
            ViewBag.userid = id;
            return View(claimlist);
        }

        
        [HttpGet]
        [Authorize]
        public IActionResult ViewClaim(int id)
        {
            var claimdetail = inc.ClaimDetails.Where(x => x.Claimno == id).FirstOrDefault();
            if (claimdetail.Status.Trim() == "Cancelled")
            {
                ViewBag.StatusCheck = "This claim already cancelled on " + claimdetail.Actiondate;
            }
            ViewBag.userid = claimdetail.Userid;
            return View(claimdetail);
        }

        //Cancel Claim by user itself
        [Authorize]
        public IActionResult CancelClaim(int id)
        {
            
            var claim = inc.ClaimDetails.Where(x => x.Claimno == id).FirstOrDefault();
            if(claim.Status.Trim() == "Pending")
            {
                claim.Status = "Cancelled";
                claim.Approvedamount = 0;
                claim.Actiondate = DateTime.Now;
                claim.Feedback = "Cancelled";
                inc.SaveChanges();
            }
            return RedirectToAction("MyClaim", new { id = claim.Userid });
        }

        //Register interface
        [HttpGet]
        public IActionResult RegisterUser()
        {
            return View();
        }

        //Register new user
        [HttpPost]
        public IActionResult RegisterUser(LoginDetail details)
        {
            if(inc.LoginDetails.Any(x=>x.Username == details.Username && x.Email == details.Email))
            {
                ViewBag.ErrorMessage = "User with same email or user Name  already exists";
                ViewBag.ShowErrorModal = true;
                return View();
            }
            else
            {
                if (ModelState.IsValid)
                {
                    if (details.Role == "Admin")
                    {
                        ViewBag.ErrorMessage("You Cannot register as a admin");
                    }
                    else
                    {
                        inc.LoginDetails.Add(details);
                        inc.SaveChanges();
                        TempData["regstatus"] = "Successfully register";
                        return RedirectToAction("Login", "Home");
                    }
                }
            }
            return View();
        }

        //Login interface
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        //Login validation
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginDetail details)
        {
            var userid = HttpContext.Session.GetInt32("Userid");
            if (userid == null)
            {
                var userLogin = inc.LoginDetails.Where(x=>x.Email == details.Email && x.Password == details.Password).FirstOrDefault();
                if (userLogin != null)
                {
                    var userRole = userLogin.Role;

                    if (userRole == "Admin")
                    {
                        HttpContext.Session.SetInt32("Userid", userLogin.Userid);
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, userLogin.Username) },
                        CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("Username", userLogin.Username);
                        string str = userLogin.Username + "Logined on " + DateTime.Now.ToString();
                        LogFileEntry(str);
                        return RedirectToAction("AdminProfile", "Admin");
                    }
                    else
                    {
                        HttpContext.Session.SetInt32("Userid", userLogin.Userid);
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, userLogin.Username) },
                        CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("Username", userLogin.Username);
                        string str = userLogin.Username + "Logined on " + DateTime.Now.ToString();
                        LogFileEntry(str);  
                        return RedirectToAction("userprofile", "Home");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "Incorrect details";
                    ViewBag.ShowErrorModal = true;
                    return View();
                }
            }
            else
            {
                ViewBag.ErrorMessage = "User Donot exists  , Sign up";
                return View();
            }
        }


        public IActionResult LogOut()
        {
            string str = HttpContext.Session.GetString("Username") + "Logout on " + DateTime.Now.ToString();
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var StoreCookies = Request.Cookies.Keys;
            foreach (var cookies in StoreCookies)
            {
                Response.Cookies.Delete(cookies);
            }
            HttpContext.Session.Clear();
            LogFileEntry(str);
            return RedirectToAction("Login", "Home");
        }
    }
}
