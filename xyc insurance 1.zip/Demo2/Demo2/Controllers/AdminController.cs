﻿using Demo2.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Demo2.Controllers
{
    
    public class AdminController : Controller
    {
        NewInsuranceDBContext inc = new NewInsuranceDBContext();

        public static void AdminAction(string message)
        {
            FileStream fs = new FileStream("C:\\Users\\prabhaharan_m\\source\\repos\\Demo2\\Demo2\\wwwroot\\NewFolder\\AdminActionFile.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(message);
            sw.Close();
        }

        //Admin interface
        [Authorize]
        public IActionResult AdminProfile()
        {
            var uid = HttpContext.Session.GetInt32("Userid");

            var user = inc.LoginDetails.Where(x => x.Userid == uid).FirstOrDefault();
            if (user != null)
            {
                return View(user);
            }
            else
            {
                ViewBag.ErrorMessage = "Try Logging in, Please!";
                return RedirectToAction("Login", "Home");
            }
        }

        //View list of pending claims
        [Authorize]
        public IActionResult ClaimRequest()
        {
            var list = inc.ClaimDetails.Where(x=>x.Status == "Pending").ToList();
            return View(list);
        }

        //View indivitual claim details
        [Authorize]
        public IActionResult ViewClaim(int id)
        {
            var claim = inc.ClaimDetails.Where(x=>x.Claimno == id).FirstOrDefault();
            var user= inc.UserDetails.Where(x => x.Policyno == claim.Policyno).FirstOrDefault();
            ViewBag.PolicyAmount = user.Policyamount;
            double max;

           if(((claim.Claimdate.Value.Year - user.Policydate.Value.Year)*12 + (claim.Claimdate.Value.Month - user.Policydate.Value.Month)) < 6)
            {
                ViewBag.DateError = "Cannot claim amount before 6 months from Policy date!!!";
            }
            

            if(user.Policytype.ToLower() == "basic")
            {
                max = user.Policyamount.Value * (0.70);
            }
            else {
                max = user.Policyamount.Value * (.90);
            }
            
            if(claim.Claimedamount == null)
            {
                claim.Claimedamount = 0;
                ViewBag.MaxError = "Claim Amount must be greater than Zero";
            }
            if((double)claim.Claimedamount > max)
            {
                ViewBag.MaxError = "Claimed amount is greater than Policy Amount";
            }
            
            return View(claim);
        }


        //Entire Claims raised by user
        [Authorize]
        public IActionResult ClaimHistory()
        {
            var claimHistory = inc.ClaimDetails.ToList();
            if(claimHistory.Count <= 0) 
            {
                ViewBag.HistoryError = "There is No Claim Available Right Now";
            }
            return View(claimHistory);
        }

        //Edit interface for Admin
        [HttpGet]
        [Authorize]
        public IActionResult EditAdmin(int id)
        {
            var admin = inc.LoginDetails.Where(x=>x.Userid == id).FirstOrDefault();
            return View(admin);

        }

        //Edit Admin details
        [HttpPost]
        [Authorize]
        public IActionResult EditAdmin(LoginDetail details)
        {
            var admin = inc.LoginDetails.Where(x=>x.Userid == details.Userid).FirstOrDefault();
            inc.LoginDetails.Remove(admin);
            inc.LoginDetails.Add(details);
            inc.SaveChanges();
            return RedirectToAction("AdminProfile");


        }

        //Approve Claims interface
        [HttpGet]
        [Authorize]
        public IActionResult ApproveClaim(int id)
        {
            var claim = inc.ClaimDetails.Where(x=>x.Claimno == id).FirstOrDefault();
            return View(claim);
        }

        //Approve claims
        [HttpPost]
        [Authorize]
        public IActionResult ApproveClaim(ClaimDetail details)
        {
            
            var claim = inc.ClaimDetails.Where(x=>x.Claimno == details.Claimno).FirstOrDefault();
            if(claim.Claimedamount < details.Approvedamount || details.Approvedamount == null)
            {
                ViewBag.MaxAmount = "Enter amount lessthan " + claim.Claimedamount.ToString();
                return View(claim);
            }
            if(details.Feedback == null)
            {
                ViewBag.FeedbackNull = "Feedback is Must!!!";
                return View(claim);
            }
            inc.ClaimDetails.Remove(claim);
            details.Actiondate = DateTime.Now;
            details.Status = "Approved";
            inc.ClaimDetails.Add(details);
            inc.SaveChanges();
            string str = HttpContext.Session.GetString("Username").ToString() + " Approved a claim having Claim No " + details.Claimno.ToString() + " on " + DateTime.Now.ToString();
            AdminAction(str);
            return RedirectToAction("ClaimRequest");
        }

        //Reject claim interface
        [HttpGet]
        [Authorize]
        public IActionResult RejectClaim(int id)
        {
            var claim = inc.ClaimDetails.Where(x => x.Claimno == id).FirstOrDefault();
            return View(claim);
        }

        //Reject Claims
        [HttpPost]
        [Authorize]
        public IActionResult RejectClaim(ClaimDetail details)
        {
            if(details.Feedback == null) 
            {
                ViewBag.FeedbackNull = "Feedback is Must!!!";
                return View(details);
                    }
            var claim = inc.ClaimDetails.Where(x => x.Claimno == details.Claimno).FirstOrDefault();
            inc.ClaimDetails.Remove(claim);
            details.Approvedamount = 0;
            details.Actiondate = DateTime.Now;
            details.Status = "Rejected";
            inc.ClaimDetails.Add(details);
            inc.SaveChanges();
            string str = HttpContext.Session.GetString("Username").ToString() + " Rejected a claim having Claim No " + details.Claimno.ToString() + " on " + DateTime.Now.ToString();
            AdminAction(str);
            return RedirectToAction("ClaimRequest");
        }


    }
}
