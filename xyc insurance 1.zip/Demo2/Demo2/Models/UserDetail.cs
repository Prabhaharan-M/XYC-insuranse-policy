﻿using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Demo2.Models
{
    public partial class UserDetail
    {
        public UserDetail()
        {
            ClaimDetails = new HashSet<ClaimDetail>();
        }
        [DisplayName("User Id")]
        public int Userid { get; set; }

        
        [MinLength(5,ErrorMessage ="Enter more than 5 character"),MaxLength(20)]
        [Required(ErrorMessage ="Customer Name is required")]
        [DisplayName("Customer Name")]
        [RegularExpression(@"^[a-zA-Z]+[ a-zA-Z-_]*$", ErrorMessage = "Use Characters only")]
        public string? Customername { get; set; }


        [Required(ErrorMessage = "Policy No is required")]
        [DisplayName("Policy No")]
        public long Policyno { get; set; }


        [Required(ErrorMessage = "Policy Type is required")]
        [DisplayName("Policy Type")]
        public string? Policytype { get; set; }


        [Required(ErrorMessage = "Category is required")]
        public string? Category { get; set; }


        [Required(ErrorMessage = "Assert No is required")]
        [DisplayName("Assertno No")]
        [RegularExpression(@"^[a-zA-Z0-9_./-][ a-zA-Z0-9-_/.]*$", ErrorMessage = "Enter valid details")]
        public string? Assertno { get; set; }

        
        [Required(ErrorMessage = "Address is required")]
        [DisplayName("Address")]
        [RegularExpression(@"^[a-zA-Z0-9_./-][ a-zA-Z0-9-_/.]*$",ErrorMessage ="Enter valid details")]
        public string? Address { get; set; }

        [Required(ErrorMessage = "Policy Amount is required")]
        [Range(50000,5000000)]
        [DisplayName("Policy Amount")]
        public int? Policyamount { get; set; }


        [Required(ErrorMessage = "Policy Date is required")]
        [DisplayName("Policy Date")]
        public DateTime? Policydate { get; set; }

        public virtual LoginDetail User { get; set; } = null!;
        public virtual ICollection<ClaimDetail> ClaimDetails { get; set; }
    }
}
