﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Demo2.Models
{
    public partial class LoginDetail
    {
        public LoginDetail()
        {
            UserDetails = new HashSet<UserDetail>();
        }

        [Required(ErrorMessage = "UserId is required**")]
        public int Userid { get; set; }

       
        [Required(ErrorMessage = "User Name is required**")]
        [MaxLength(20)]
        [MinLength(5,ErrorMessage ="Enter atleast 5 character!!")]
        [RegularExpression(@"^[a-zA-Z]*$", ErrorMessage = "Use Characters only")]
        public string? Username { get; set; }

        
        [Required(ErrorMessage = "Password is required**")]
        [MaxLength(20)]
        [MinLength(5 , ErrorMessage = "Enter atleast 5 character!!")]
        //[RegularExpression(@"^[a-zA-Z0-9_./-]*$", ErrorMessage = "Enter valid details")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$", ErrorMessage = "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one digit.")]
        public string? Password { get; set; }


        [Required(ErrorMessage = "Mobile No is required**")]
        [MinLength(10,ErrorMessage ="Enter 10 digit Valid Number")]
        [MaxLength(10)]
        [RegularExpression(@"^[0-9]*$",ErrorMessage ="Enter Number only")]
        public string? Mobile { get; set; }

        
        [Required(ErrorMessage = "Email is required**")]
        [MaxLength(20)]
        [MinLength(10,ErrorMessage ="Enter valid email Address")]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$", ErrorMessage ="Enter valid Email Address")]
        public string? Email { get; set; }


        [Required(ErrorMessage = "Role is required**")]
        [MaxLength(5)]
        public string? Role { get; set; }

        public virtual ICollection<UserDetail> UserDetails { get; set; }
    }
}
