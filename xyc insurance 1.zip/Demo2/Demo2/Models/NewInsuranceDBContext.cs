﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Demo2.Models
{
    public partial class NewInsuranceDBContext : DbContext
    {
        public NewInsuranceDBContext()
        {

        }

        public NewInsuranceDBContext(DbContextOptions<NewInsuranceDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ClaimDetail> ClaimDetails { get; set; } = null!;
        public virtual DbSet<LoginDetail> LoginDetails { get; set; } = null!;
        public virtual DbSet<UserDetail> UserDetails { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=NewInsuranceDB;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ClaimDetail>(entity =>
            {
                entity.HasKey(e => e.Claimno);

                entity.ToTable("claim_details");

                entity.Property(e => e.Claimno).HasColumnName("claimno");

                entity.Property(e => e.Actiondate)
                    .HasColumnType("datetime")
                    .HasColumnName("actiondate");

                entity.Property(e => e.Approvedamount)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("approvedamount");

                entity.Property(e => e.Claimdate)
                    .HasColumnType("datetime")
                    .HasColumnName("claimdate");

                entity.Property(e => e.Claimedamount)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("claimedamount");

                entity.Property(e => e.Claimreason)
                    .HasMaxLength(100)
                    .HasColumnName("claimreason");

                entity.Property(e => e.Feedback)
                    .HasMaxLength(100)
                    .HasColumnName("feedback");

                entity.Property(e => e.Policyno).HasColumnName("policyno");

                entity.Property(e => e.Status)
                    .HasMaxLength(20)
                    .HasColumnName("status")
                    .IsFixedLength();

                entity.Property(e => e.Userid).HasColumnName("userid");

                entity.HasOne(d => d.PolicynoNavigation)
                    .WithMany(p => p.ClaimDetails)
                    .HasForeignKey(d => d.Policyno)
                    .HasConstraintName("FK__claim_det__polic__29572725");
            });

            modelBuilder.Entity<LoginDetail>(entity =>
            {
                entity.HasKey(e => e.Userid)
                    .HasName("PK__login_de__CBA1B257A784B700");

                entity.ToTable("login_details");

                entity.Property(e => e.Userid).HasColumnName("userid");

                entity.Property(e => e.Email)
                    .HasMaxLength(20)
                    .HasColumnName("email")
                    .IsFixedLength();

                entity.Property(e => e.Mobile)
                    .HasMaxLength(10)
                    .HasColumnName("mobile")
                    .IsFixedLength();

                entity.Property(e => e.Password)
                    .HasMaxLength(20)
                    .HasColumnName("password")
                    .IsFixedLength();

                entity.Property(e => e.Role)
                    .HasMaxLength(5)
                    .HasColumnName("role")
                    .IsFixedLength();

                entity.Property(e => e.Username)
                    .HasMaxLength(20)
                    .HasColumnName("username")
                    .IsFixedLength();
            });

            modelBuilder.Entity<UserDetail>(entity =>
            {
                entity.HasKey(e => e.Policyno)
                    .HasName("PK_Table");

                entity.ToTable("user_details");

                entity.Property(e => e.Policyno).HasColumnName("policyno");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .HasColumnName("address")
                    .IsFixedLength();

                entity.Property(e => e.Assertno)
                    .HasMaxLength(20)
                    .HasColumnName("assertno")
                    .IsFixedLength();

                entity.Property(e => e.Category)
                    .HasMaxLength(20)
                    .HasColumnName("category")
                    .IsFixedLength();

                entity.Property(e => e.Customername)
                    .HasMaxLength(20)
                    .IsFixedLength();

                entity.Property(e => e.Policyamount).HasColumnName("policyamount");

                entity.Property(e => e.Policydate)
                    .HasColumnType("datetime")
                    .HasColumnName("policydate");

                entity.Property(e => e.Policytype)
                    .HasMaxLength(20)
                    .HasColumnName("policytype")
                    .IsFixedLength();

                entity.Property(e => e.Userid).HasColumnName("userid");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserDetails)
                    .HasForeignKey(d => d.Userid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__user_deta__useri__267ABA7A");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
