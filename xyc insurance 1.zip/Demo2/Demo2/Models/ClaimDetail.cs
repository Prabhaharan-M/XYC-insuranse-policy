﻿
using Microsoft.CodeAnalysis.Completion;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;




namespace Demo2.Models
{
    public partial class ClaimDetail
    {
        [Required(ErrorMessage ="User Id is required**")]
        [DisplayName("User Id")]
        public int Userid { get; set; }
        [Required(ErrorMessage = "Policy No is required**")]
        [DisplayName("Policy No")]
        public long? Policyno { get; set; }
        [Required(ErrorMessage = "Claim No is required**")]
        [DisplayName("Claim No")]
        public long Claimno { get; set; }
        [Required(ErrorMessage = "Claim Date is required**")]
        [DisplayName("Claim Date")]
        public DateTime? Claimdate { get; set; }
        [Required(ErrorMessage = "Claim Amount is required**")]
        [Range(0,5000000,ErrorMessage ="Enter valid amount")]
        [DisplayName("Claim Amount")]
        public decimal? Claimedamount { get; set; }
        [Range(0,5000000)]
        [DisplayName("Approved Amount")]
        public decimal? Approvedamount { get; set; }
        [Required(ErrorMessage = "Claim Reason is required**")]
        [DisplayName("Claim Reason")]
        [RegularExpression(@"^[a-zA-Z0-9]+[ a-zA-Z0-9-_]*$", ErrorMessage = "Use Characters only")]
        public string? Claimreason { get; set; }

        [RegularExpression(@"^[a-zA-Z0-9_./-][ a-zA-Z0-9-_/.]*$", ErrorMessage = "Enter valid Feedback")]
        public string? Feedback { get; set; }
        [DisplayName("Action Date")]
        public DateTime? Actiondate { get; set; }
        [Required]
        public string? Status { get; set; }

        public virtual UserDetail? PolicynoNavigation { get; set; }
    }
}
